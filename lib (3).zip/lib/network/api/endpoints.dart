class Endpoints {
  // Auth
  static const String login = '/CustomerLoginByID';
  static const String signup = '/CreateCustomerInformation';
  static const String otherLogin = '/CustomerLoginByEmailPhone';
  // Forgot password (OTP) flow
  static const String resetCustomerPasswordOtp = '/ResetCustomerPasswordOTP';
  static const String resetCustomerEmailPhonePasswordOtp =
      '/ResetCustomerEmailPhonePasswordOTP';
  static const String validateCustomerPasswordOtp =
      '/ValidateCustomerPasswordOTP';
  static const String validateCustomerPasswordEmailPhoneOtp =
      '/ValidateCustomerPasswordEmailPhoneOTP';

  // Lead Management
  static const String createLead = '/CreateLeadInformation';
  static const String getLeadByID = '/GetLeadInformationByID';
  static const String convertLeadToCustomer = '/ConvertLeadToCustomer';

  // Profile
  static const String profile = '/GetCustomerInformationByID';
  static const String profileByEmail = '/GetCustomerInformationByEmailPhone';
  static const String changePassword = '/ChangeCustomerPassword';

  // Policies
  static const String customerPolicies = '/GetInsurancePolicyByCustomerID';
  static const String customerClaims = '/GetInsurancePolicyClaimsByCustomerID';
  static const String getInsuranceBusinessClass = '/GetInsuranceBusinessClass';
  static const String getSingleInsuranceBusinessClass =
      '/GetClmDocsByBusinessClassID';
  static const String getInsuranceRiskType =
      '/GetInsuranceRiskTypeByBusinessClassID';
  static const String renewPolicy = '/InsurancePolicyRenewal';
  static const String updateInsurancePolicy = '/UpdateInsurancePolicyByID';
  // +++ ADD:
  static const String endorsePolicy = '/EndorseInsurancePolicy';
  static const String createClientNoteEndorsement =
      '/CreateInsuranceClientNoteEndorsement';
  static const String bookPolicy = '/InsurancePolicyBooking';
  static const String postPolicy = '/InsurancePolicyPost';
  static const String createClientNote = '/CreateInsuranceClientNote';
  static const String bookClientNote = '/InsuranceClientNoteBooking';
  static const String postClientNote = '/InsuranceClientNotePost';
  static const String createInsurancePolicy = '/CreateInsurancePolicyClient';
  static const String getPremiumAmount = '/GetComputePolicyPremium';
  static const String getPaymentToken = '/GetCompanyPayment';
  static const String createReceipt = '/CreateCustomerReceipts';
  static const String postReceipt = '/CustomerReceiptPost';
  static const String updatePolicyItem = '/UpdateInsurancePolicyItemToInsure';
  static const String createPolicyItem = '/CreateInsurancePolicyItemToInsure';
  static const String createClaims = '/CreateInsurancePolicyClaims';
  static const String claimRecalc = '/InsurancePolicyClaimsRecalc';
  static const String updateClaims = '/UpdateInsurancePolicyClaimsByID';
  static const String uploadClaimDoc = '/UpLoadClaimsDocuments';
  static const String getClaimDocuments = '/GetClaimsDocumentsByID';
  static const String getClaim = '/GetInsurancePolicyClaimsByID';
  static const String sendToBroker = '/createCustomerEnquiry';
  static const String submitClaim = '/SubmitClaim';
  static const String quotes = '/GetCustomerEnquiriesByCustomerID';

  // Quote Management (New Flow)
  static const String createSalesQuotation = '/CreateSalesQuotation';
  static const String updateSalesQuotation = '/UpdateSalesQuotation';
  static const String getSalesQuotationByID = '/GetSalesQuotationsByID';
  static const String getSalesQuotationsByEntityID =
      '/GetSalesQuotationsByEntityID';

  // Transactions
  // Transactions
  static const String getClientNotesByCustomer =
      '/GetInsuranceClientNotesByCustomerID';
  static const String getCustomerTransactions =
      '/GetCustomerTransactionsByCustomer';
  static const String viewCustomerTransactionReport =
      '/ViewCustomerTransactionReport';
  static const String viewCustomerStatementReport =
      '/ViewCustomerStatementReport';
  static const String viewPremiumDemandNoteReport =
      '/ViewPremiumDemandNoteReport';

  // Vendors / Enquiries
  static const String getVendors = '/GetVendorInformation';
  static const String getCustomerEnquiryById = '/GetCustomerEnquiriesByID';
  static const String updateCustomerEnquiryStatus =
      '/UpdateCustomerEnquiryStatus'; // NEW

  // About Section
  static const String getCompanyInfo = '/GetCompanyInformationByID';
  static const String getCompanyFaq = '/GetCompanyFAQ';
  static const String getCompanyChat = '/GetCompanyChat';
  // Policy documents
  static const String viewInsuranceCertificate = '/viewInsuranceCertificate';
}
