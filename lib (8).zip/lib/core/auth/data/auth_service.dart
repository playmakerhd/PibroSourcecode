import 'package:get/get.dart';
import 'package:pibro/core/config/model/config_model.dart';
import 'package:pibro/constants/storage_keys.dart';
import 'package:pibro/utils/app_utils.dart';

class AuthService extends GetConnect {
  late String _baseUrl;
  late String _token;

  AuthService() {
    httpClient.timeout = const Duration(seconds: 30);
    _initializeConfig();
  }

  void _initializeConfig() {
    final configData =
        ConfigData.fromJson(convertToJsonStringQuotes(StorageKeys.configData));
    _baseUrl = configData.url ?? '';
    _token = configData.token ?? '';
  }

  /// Send OTP for password reset using CustomerID (username)
  /// Endpoint: {baseUrl}/ResetCustomerPasswordOTP/{token}?CustomerID={CustomerID}
  Future<Response> resetCustomerPasswordOtp({
    required String customerId,
  }) {
    final url =
        '$_baseUrl/ResetCustomerPasswordOTP/$_token?CustomerID=$customerId';
    return get(url);
  }

  /// Send OTP for password reset using CustomerEmail and CustomerPhone
  /// Endpoint: {baseUrl}/ResetCustomerEmailPhonePasswordOTP/{token}?CustomerEmail={CustomerEmail}&CustomerPhone={CustomerPhone}
  Future<Response> resetCustomerEmailPhonePasswordOtp({
    required String customerEmail,
    required String customerPhone,
  }) {
    final url =
        '$_baseUrl/ResetCustomerEmailPhonePasswordOTP/$_token?CustomerEmail=${Uri.encodeComponent(customerEmail)}&CustomerPhone=${Uri.encodeComponent(customerPhone)}';
    return get(url);
  }

  /// Validate OTP and change password when OTP was requested with CustomerID
  /// Endpoint: {baseUrl}/ValidateCustomerPasswordOTP/{token}?CustomerID={CustomerID}&OTP={OTP}&NewPassword={NewPassword}
  Future<Response> validateCustomerPasswordOtp({
    required String customerId,
    required String otp,
    required String newPassword,
  }) {
    final url =
        '$_baseUrl/ValidateCustomerPasswordOTP/$_token?CustomerID=${Uri.encodeComponent(customerId)}&OTP=${Uri.encodeComponent(otp)}&NewPassword=${Uri.encodeComponent(newPassword)}';
    return get(url);
  }

  /// Validate OTP and change password when OTP was requested with email & phone
  /// Endpoint: {baseUrl}/ValidateCustomerPasswordEmailPhoneOTP/{token}?CustomerEmail={CustomerEmail}&CustomerPhone={CustomerPhone}&OTP={OTP}&NewPassword={NewPassword}
  Future<Response> validateCustomerPasswordEmailPhoneOtp({
    required String customerEmail,
    required String customerPhone,
    required String otp,
    required String newPassword,
  }) {
    final url =
        '$_baseUrl/ValidateCustomerPasswordEmailPhoneOTP/$_token?CustomerEmail=${Uri.encodeComponent(customerEmail)}&CustomerPhone=${Uri.encodeComponent(customerPhone)}&OTP=${Uri.encodeComponent(otp)}&NewPassword=${Uri.encodeComponent(newPassword)}';
    return get(url);
  }
}
