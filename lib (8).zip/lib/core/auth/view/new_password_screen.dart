import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pibro/constants/app_images.dart';
import 'package:pibro/shared/auth_bg.dart';
import 'package:pibro/core/auth/controller/forgot_password_controller.dart';
import 'package:pibro/navigation/routes.dart';
import 'package:pibro/shared/widget/app_text_field.dart';
import 'package:pibro/shared/custom_button.dart';

class NewPasswordScreen extends GetView<ForgotPasswordController> {
  const NewPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final String username = (Get.arguments?['username'] ?? '') as String;

    return AuthBg(
      title: 'Set New Password',
      showBack: false,
      titleWidget: Image.asset(AppImages.pibroLogo, height: 50),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Center(child: const _Title('Set New Password')),
            const SizedBox(height: 8),
            Center(
              child: const Text(
                'Must be at least 8 characters',
                style: TextStyle(fontSize: 13, color: Color(0xFF0E3B66)),
              ),
            ),
            const SizedBox(height: 28),
            AppTextField(
              controller: controller.newPwdCtrl,
              hint: 'Enter new password',
              obscure: true,
            ),
            const SizedBox(height: 15),
            const SizedBox(height: 5),
            const SizedBox(height: 36),
            Obx(() => CustomButton(
                  text: 'Confirm',
                  loading: controller.isBusy.value,
                  onPressed: () =>
                      controller.confirmNewPassword(username: username),
                  height: 50,
                  borderRadius: 80,
                  color: const Color(0xFF0E3B66),
                )),
            const SizedBox(height: 24),
            _BackToLogin(onTap: () => Get.offAllNamed(AppRoutes.login)),
          ],
        ),
      ),
    );
  }
}

// Header provided by shared MainHeader

class _Title extends StatelessWidget {
  final String text;
  const _Title(this.text);

  @override
  Widget build(BuildContext context) => Text(text,
      style: const TextStyle(
          fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF0E3B66)));
}

class _BackToLogin extends StatelessWidget {
  final VoidCallback onTap;
  const _BackToLogin({required this.onTap});

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.arrow_back,
            color: Color(0xFF0E3B66),
            size: 12,
          ),
          const SizedBox(width: 5),
          InkWell(
            onTap: onTap,
            child: const Text('Back to login',
                style: TextStyle(fontSize: 12, color: Color(0xFF0E3B66))),
          ),
        ],
      );
}
