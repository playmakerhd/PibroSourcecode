import 'dart:async';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:pibro/constants/app_colors.dart';
import 'package:pibro/navigation/routes.dart';
import 'package:pibro/shared/widget/success_dialog.dart' as ssd;
import '../data/auth_service.dart';

class ForgotPasswordController extends GetxController {
  final AuthService _api = Get.put(AuthService(), permanent: true);

  // Form controllers
  final usernameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final newPwdCtrl = TextEditingController();
  // confirm password removed per new flow

  // State management
  final isBusy = false.obs;
  final code = ''.obs; // 6 digits from OTP screen
  final isOtherOption = false.obs; // Toggle between username and email+phone
  final usedEmailPhone = false.obs; // whether OTP requested via email+phone

  // Resend timer: OTP resend is allowed every 2 minutes
  final RxInt resendSeconds = 0.obs;
  final RxBool canResend = false.obs;
  Timer? _resendTimer;
  String? lastCustomerId;
  final int _resendInterval = 120; // seconds

  // --- Toggle Methods ---
  void toggleOtherOption() {
    isOtherOption.value = !isOtherOption.value;
    // Clear fields when switching
    usernameCtrl.clear();
    emailCtrl.clear();
    phoneCtrl.clear();
  }

  // --- API Actions ---
  Future<void> sendCodeWithUsername() async {
    final username = usernameCtrl.text.trim();
    if (username.isEmpty) {
      _snack('Username required', isError: true);
      return;
    }
    usedEmailPhone.value = false;
    await _sendCodeWithUsername(customerId: username);
  }

  // For email+phone option - currently shows guidance to use username
  Future<void> sendCodeWithEmailPhone() async {
    final email = emailCtrl.text.trim();
    final phone = phoneCtrl.text.trim();
    if (email.isEmpty || phone.isEmpty) {
      _snack('Enter both Email and Phone', isError: true);
      return;
    }
    // basic email validation
    if (!RegExp(r"^[\w\.-]+@[\w\.-]+\.[a-zA-Z]{2,}").hasMatch(email)) {
      _snack('Enter a valid email', isError: true);
      return;
    }
    // basic phone validation (digits only, 7-15 chars)
    if (!RegExp(r"^[0-9]{7,15}").hasMatch(phone)) {
      _snack('Enter a valid phone number', isError: true);
      return;
    }
    usedEmailPhone.value = true;
    await _sendCodeWithEmailPhone(email: email, phone: phone);
  }

  Future<void> _sendCodeWithUsername({required String customerId}) async {
    lastCustomerId = customerId;
    try {
      isBusy.value = true;
      final res = await _api.resetCustomerPasswordOtp(customerId: customerId);
      if (res.isOk) {
        _snack('A 6-digit code has been sent to your registered email');
        Get.toNamed(AppRoutes.otpReset, arguments: {'username': customerId});
      } else {
        _snack(_extractError(res.bodyString) ?? 'Failed to send code',
            isError: true);
      }
    } catch (e) {
      _snack('Network error: $e', isError: true);
    } finally {
      isBusy.value = false;
    }
  }

  Future<void> _sendCodeWithEmailPhone(
      {required String email, required String phone}) async {
    // record last values for resend/validation
    lastCustomerId = null;
    try {
      isBusy.value = true;
      final res = await _api.resetCustomerEmailPhonePasswordOtp(
          customerEmail: email, customerPhone: phone);
      if (res.isOk) {
        _snack('A 6-digit code has been sent to your registered email');
        Get.toNamed(AppRoutes.otpReset,
            arguments: {'email': email, 'phone': phone});
      } else {
        _snack(_extractError(res.bodyString) ?? 'Failed to send code',
            isError: true);
      }
    } catch (e) {
      _snack('Network error: $e', isError: true);
    } finally {
      isBusy.value = false;
    }
  }

  /// Call when user navigates into the OTP screen. This records the username
  /// and starts the resend countdown (2 minutes) if not already running.
  void enterOtpScreen(String username) {
    lastCustomerId = username;
    // Always (re)start the countdown when entering the screen
    startResendTimer();
  }

  void startResendTimer() {
    _resendTimer?.cancel();
    resendSeconds.value = _resendInterval;
    canResend.value = false;
    _resendTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (resendSeconds.value <= 1) {
        canResend.value = true;
        resendSeconds.value = 0;
        t.cancel();
      } else {
        resendSeconds.value = resendSeconds.value - 1;
      }
    });
  }

  Future<void> resendCode({String? username}) async {
    if (!canResend.value) return;
    final id = username ?? lastCustomerId;
    if (!usedEmailPhone.value) {
      if (id == null || id.isEmpty) {
        _snack('Username required', isError: true);
        return;
      }
    }
    try {
      isBusy.value = true;
      Response res;
      if (usedEmailPhone.value) {
        // when email+phone was used, lastCustomerId is null; expect email/phone passed
        final email = Get.arguments?['email'] as String? ?? '';
        final phone = Get.arguments?['phone'] as String? ?? '';
        if (email.isEmpty || phone.isEmpty) {
          _snack('Email and phone required to resend', isError: true);
          return;
        }
        res = await _api.resetCustomerEmailPhonePasswordOtp(
            customerEmail: email, customerPhone: phone);
      } else {
        res = await _api.resetCustomerPasswordOtp(customerId: id!);
      }
      if (res.isOk) {
        _snack('Code resent to your registered email address');
        startResendTimer();
      } else {
        _snack(_extractError(res.bodyString) ?? 'Failed to resend code',
            isError: true);
      }
    } catch (e) {
      _snack('Network error: $e', isError: true);
    } finally {
      isBusy.value = false;
    }
  }

  Future<void> confirmNewPassword({required String username}) async {
    final newPwd = newPwdCtrl.text;
    final oldOtp = code.value;

    // Validations
    if (newPwd.length < 8) {
      _snack('Password must be at least 8 characters', isError: true);
      return;
    }
    if (oldOtp.length != 6) {
      _snack('Invalid 6-digit code', isError: true);
      return;
    }

    try {
      isBusy.value = true;
      Response res;
      if (usedEmailPhone.value) {
        final email = Get.arguments?['email'] as String? ?? '';
        final phone = Get.arguments?['phone'] as String? ?? '';
        if (email.isEmpty || phone.isEmpty) {
          _snack('Email and phone required', isError: true);
          return;
        }
        res = await _api.validateCustomerPasswordEmailPhoneOtp(
          customerEmail: email,
          customerPhone: phone,
          otp: oldOtp,
          newPassword: newPwd,
        );
      } else {
        // username flow
        res = await _api.validateCustomerPasswordOtp(
          customerId: username,
          otp: oldOtp,
          newPassword: newPwd,
        );
      }

      if (res.isOk) {
        await ssd.showSuccessDialog(
          title: 'Success',
          message: 'Password reset Successfully',
          onPressed: () => Get.offAllNamed(AppRoutes.login),
          dismissible: false,
          willPop: false,
        );
      } else {
        _snack(_extractError(res.bodyString) ?? 'Unable to change password',
            isError: true);
      }
    } catch (e) {
      _snack('Network error: $e', isError: true);
    } finally {
      isBusy.value = false;
    }
  }

  // --- UI Helpers ---
  void _snack(String msg, {bool isError = false}) {
    Get.snackbar(
      isError ? 'Error' : 'Success',
      msg,
      backgroundColor: isError
          ? AppColors.red.withOpacity(.95)
          : AppColors.green.withOpacity(.95),
      colorText: Colors.white,
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    );
  }

  String? _extractError(String? body) {
    if (body == null) return null;
    // Keep simple: many endpoints return string messages
    if (body.length < 200) return body.replaceAll(RegExp(r'[\{\}\[\]\"]'), ' ');
    return null;
  }

  // Removed inline _showSuccessDialog — standardized to shared success dialog helper

  @override
  void onClose() {
    usernameCtrl.dispose();
    emailCtrl.dispose();
    phoneCtrl.dispose();
    newPwdCtrl.dispose();
    _resendTimer?.cancel();
    super.onClose();
  }
}
