// ... existing code
class ItemToInsure {
  String? companyID;
  String? divisionID;
  String? departmentID;
  String? policyBrokerID;
  String? policyItemsID;
  String? sectionTypeID;
  String? manualNumbering;
  int? brokingSlipItemCount;
  String? itemsDescription;
  double? sumInsured;
  String? itemLocation;
  String? policyItems;

  ItemToInsure({
    this.companyID,
    this.divisionID,
    this.departmentID,
    this.policyBrokerID,
    this.policyItemsID,
    this.sectionTypeID,
    this.manualNumbering,
    this.brokingSlipItemCount,
    this.itemsDescription,
    this.sumInsured,
    this.itemLocation,
    this.policyItems,
  });

  factory ItemToInsure.fromJson(Map<String, dynamic> json) {
    return ItemToInsure(
      companyID: json['CompanyID'],
      divisionID: json['DivisionID'],
      departmentID: json['DepartmentID'],
      policyBrokerID: json['PolicyBrokerID'],
      policyItemsID: json['PolicyItemsID'],
      sectionTypeID: json['SectionTypeID'],
      manualNumbering: json['ManualNumbering'],
      brokingSlipItemCount: json['BrokingSlipItemCount'],
      itemsDescription: json['ItemsDescription'],
      sumInsured: (json['SumInsured'] as num?)?.toDouble(),
      itemLocation: json['ItemLocation'],
      policyItems: json['PolicyItems'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'CompanyID': companyID,
      'DivisionID': divisionID,
      'DepartmentID': departmentID,
      'PolicyBrokerID': policyBrokerID,
      'PolicyItemsID': policyItemsID,
      'SectionTypeID': sectionTypeID,
      'ManualNumbering': manualNumbering,
      'BrokingSlipItemCount': brokingSlipItemCount,
      'ItemsDescription': itemsDescription,
      'SumInsured': sumInsured,
      'ItemLocation': itemLocation,
      'PolicyItems': policyItems,
    };
  }

  Map<String, dynamic> toCreatePayload() => {
        "PolicyBrokerID": policyBrokerID,
        "SectionTypeID": sectionTypeID,
        "ManualNumbering": manualNumbering,
        "BrokingSlipItemCount": brokingSlipItemCount ?? 0,
        "ItemsDescription": itemsDescription,
        "SumInsured": sumInsured,
        "ItemLocation": itemLocation,
        "PolicyItems": policyItems ?? "",
      };
}
