import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pibro/constants/app_colors.dart';
import 'package:pibro/constants/app_constants.dart';
import 'package:pibro/constants/app_images.dart';
import 'package:pibro/constants/app_styles.dart';
import 'package:pibro/core/policy/views/items_to_insure_screen.dart';
import 'package:pibro/core/policy/views/payment_screen.dart';
import 'package:pibro/core/policy/widget/policy_button.dart';
import 'package:pibro/core/profile/widget/profile_button.dart';
import 'package:pibro/internalization/app_strings.dart';
import 'package:pibro/navigation/routes.dart';
import 'package:pibro/network/api/api_provider.dart';
import 'package:pibro/network/models/request/client_note_request.dart';
import 'package:pibro/network/models/request/create_poilcy_request.dart';
import 'package:pibro/network/models/request/create_receipt_request.dart';
import 'package:pibro/network/models/request/get_premium_amount_request.dart';
import 'package:pibro/network/models/request/renew_policy_requesst.dart';
import 'package:pibro/network/models/response/business_policy_response.dart';
import 'package:pibro/network/models/response/customer_policy_response.dart';
import 'package:pibro/network/models/response/insurance_risk_type_response.dart';
import 'package:pibro/network/repository/pibro_repository.dart';
import 'package:pibro/shared/custom_input/custom_input.dart';
import 'package:get_storage/get_storage.dart';
import 'package:pibro/constants/storage_keys.dart';
import 'package:pibro/core/quote/controller/get_quote_controller.dart';

import 'package:pibro/utils/api_utils.dart';
import 'package:pibro/utils/app_utils.dart';
import 'package:pibro/utils/image_factory.dart';
import 'package:pibro/utils/validators.dart';
import 'package:pibro/utils/view_utils.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';

class RenewPolicyController extends GetxController {
  PibroRepository pibroRepository =
      PibroRepository(appApiProvider: ApiProvider());
  RxBool businessLoading = false.obs;
  RxBool riskTypeLoading = false.obs;
  RxBool renewPolicyLoading = false.obs;
  RxBool submitQuoteLoading = false.obs;
  RxBool getPremiumAmountLoading = false.obs;
  RxBool paymentLoading = false.obs;
  bool isQuoteFlow = false;

  Rxn<DateTime> startDate = Rxn<DateTime>();
  final TextEditingController startDateController = TextEditingController();
  Rxn<DateTime> endDate = Rxn<DateTime>();
  final TextEditingController endDateController = TextEditingController();
  final TextEditingController renewalDateController = TextEditingController();
  final GlobalKey<FormState> addItemFormKey = GlobalKey<FormState>();
  final GlobalKey<FormState> renewFormKey = GlobalKey<FormState>();

  final TextEditingController regNoController = TextEditingController();
  final TextEditingController chasisIdController = TextEditingController();
  final TextEditingController engineNoController = TextEditingController();
  final TextEditingController vehicleMakeController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController valueController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  RxList<BusinessPolicy> businessPolicies = RxList<BusinessPolicy>([]);
  Rxn<BusinessPolicy> selectedBusinessPolicy = Rxn<BusinessPolicy>();
  RxList<RiskTypeID> riskTypeIDs = RxList<RiskTypeID>([]);
  Rxn<RiskTypeID> selectedRiskTypeID = Rxn<RiskTypeID>();

  Rxn<PolicyData> policy = Rxn<PolicyData>();
  RxList<ItemToInsure> policyItems = RxList<ItemToInsure>([]);
  RxList<ItemToInsure> newPolicyItems = RxList<ItemToInsure>([]);
  // optional base64 image placeholder for item create / update (renew-only)
  RxString selectedImageBase64 = ''.obs;
  final RxBool isPickingFile = false.obs;
  static const String _sectionTypeId = 'SECTIONA';

  String policyPremiumAmount = '';
  String _accessToken = '';
  CreateReceiptRequest createReceiptRequest = CreateReceiptRequest();
  ClientNoteRequest clientNoteRequest = ClientNoteRequest();
  late RenewPolicyRequest _renewPolicyRequest;

// To make reference available outside the sccope of verifyPayment
  String? lastPaymentReference;
  String? lastPaymentDate;
  int? lastPaymentAmount;

  // PAYMENT
  late InAppWebViewController webViewController;
  final ScreenshotController screenshotController = ScreenshotController();

  Future<void> getInsuranceBusinessClass() async {
    businessLoading.value = true;
    try {
      final response = await pibroRepository.getInsuranceBusinessClass();
      businessPolicies.value = response.businessPolicies;
      selectedBusinessPolicy.value = businessPolicies.firstWhere(
          (item) => item.businessClassID == policy.value!.businessClassID!);
      businessLoading.value = false;
    } catch (e) {
      businessLoading.value = false;
      showSnackbarMessage(
          message: AppStrings.genericErrorMessage.tr, isSuccess: false);
    }
  }

  // void selectBusinessClass(dynamic value) {
  //   selectedBusinessPolicy.value = value;
  //   getInsuranceRiskTypeID((value as BusinessPolicy).businessClassID!);
  //   selectedRiskTypeID.value = null;
  // }

  // void selectRiskType(dynamic value) {
  //   selectedRiskTypeID.value = value;
  // }

  Future<void> getInsuranceRiskTypeID() async {
    riskTypeLoading.value = true;
    try {
      final response = await pibroRepository
          .getInsuranceRiskType(policy.value!.businessClassID!);
      // riskTypeIDs.clear();
      riskTypeIDs.value = response.riskTypeIDs;
      selectedRiskTypeID.value = riskTypeIDs
          .firstWhere((item) => item.riskTypeID == policy.value!.riskTypeID!);
      riskTypeLoading.value = false;
    } catch (e) {
      riskTypeLoading.value = false;
      showSnackbarMessage(
          message: AppStrings.genericErrorMessage.tr, isSuccess: false);
    }
  }

  Future<void> getPremiumAmount() async {
    getPremiumAmountLoading.value = true;
    try {
      final response = await pibroRepository.getPremiumAmount(
        GetPremiumAmountRequest(
          brokerId: policy.value!.policyBrokerID,
          startDate: startDateController.text,
          endDate: endDateController.text,
        ),
      );
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
      } else {
        policyPremiumAmount = response.messageResponse.message;
        Get.to(() => ItemsToInsureScreen(controller: this));
      }
      getPremiumAmountLoading.value = false;
    } catch (e) {
      getPremiumAmountLoading.value = false;
      showSnackbarMessage(
          message: AppStrings.genericErrorMessage.tr, isSuccess: false);
    }
  }

  continueRenew() {
    if (renewFormKey.currentState!.validate()) {
      getPremiumAmount();
    }
  }

  void _showSuccessDialog() {
    showAppDialog(
      dismissible: false,
      willPop: false,
      Padding(
        padding: const EdgeInsets.only(top: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ImageFactory.getImage(AppImages.passwordSuccess).render(
              height: 65,
              width: 65,
            ),
            Column(
              children: [
                Text(
                  AppStrings.renewPolicy.tr,
                  style: Styles.semiBoldTextStyle(
                    color: AppColors.white,
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  AppStrings.renewPolicySuccess.tr,
                  style: Styles.mediumTextStyle(
                    size: 12,
                    color: AppColors.white,
                  ),
                ),
              ],
            ),
            GestureDetector(
              onTap: () => Get.offAllNamed(AppRoutes.main),
              child: ProfileButton(
                text: AppStrings.ok.tr,
                height: 25,
                width: 80,
                textColor: AppColors.activeGreen,
                bgColor: AppColors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> submitQuote() async {
    submitQuoteLoading.value = true;
    try {
      final response = await pibroRepository
          .sendToBroker(ApiUtils.sendPolicyToBroker(policy.value!));
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
      } else {
        _showSuccessDialog();
      }
      submitQuoteLoading.value = false;
    } catch (e) {
      submitQuoteLoading.value = false;
      showSnackbarMessage(
          message: AppStrings.genericErrorMessage.tr, isSuccess: false);
    }
  }

  Future<void> submitItemToInsure() async {
    Get.toNamed(AppRoutes.renewPolicyConfirmation);
  }

  Future<void> pickImage() async {
    if (isPickingFile.value) return;
    isPickingFile.value = true;
    try {
      final result = await FilePicker.platform.pickFiles();
      if (result != null && result.files.single.path != null) {
        selectedImageBase64.value =
            await convertFileToBase64(File(result.files.single.path!));
      } else {
        selectedImageBase64.value = '';
      }
    } catch (_) {
      selectedImageBase64.value = '';
    } finally {
      isPickingFile.value = false;
    }
  }

  void addOrUpdateItem({ItemToInsure? data, required bool isNew}) async {
    if (!addItemFormKey.currentState!.validate()) return;

    final desc = descriptionController.text;
    final sum =
        double.tryParse(valueController.text.replaceAll(',', '')) ?? 0.0;
    final loc = locationController.text;

    try {
      if (data != null) {
        // --- UPDATE PATH ---
        // Update UI model fields
        data.itemsDescription = desc;
        data.sumInsured = sum;
        data.itemLocation = loc;
        // send base64 if user attached one; otherwise empty string
        data.policyItems = selectedImageBase64.value.isNotEmpty
            ? selectedImageBase64.value
            : "";

        // guard required identifiers
        if ((data.policyBrokerID == null || data.policyBrokerID!.isEmpty) ||
            (data.sectionTypeID == null ||
                data.sectionTypeID.toString().isEmpty) ||
            (data.manualNumbering == null || data.manualNumbering!.isEmpty) ||
            (data.brokingSlipItemCount == null)) {
          showSnackbarMessage(
            message:
                'Missing required item identifiers (BrokerID/SectionType/ManualNumbering/BrokingSlipItemCount). Please reopen renew from policy to reload items.',
            isSuccess: false,
          );
          return;
        }

        final res = await pibroRepository.addOrUpdateItemToInsure(data, false);
        if (res.messageResponse.status != AppConstants.responseSuccess) {
          showSnackbarMessage(
              message: res.messageResponse.message, isSuccess: false);
          return;
        }

        // replace item in local list
        final list = isNew ? newPolicyItems : policyItems;
        final idx = list.indexWhere((it) => identical(it, data) || it == data);
        if (idx >= 0) list[idx] = data;

        showSnackbarMessage(message: 'Item updated.', isSuccess: true);
        _closeSheet();
        return;
      }

      // --- CREATE PATH ---
      final newItem = ItemToInsure(
        companyID: policy.value!.companyID,
        divisionID: policy.value!.divisionID,
        departmentID: policy.value!.departmentID,
        policyBrokerID: policy.value!.policyBrokerID,
        manualNumbering: _nextManualNumbering(),
        brokingSlipItemCount: 0,
        itemsDescription: desc,
        sumInsured: sum,
        itemLocation: loc,
        sectionTypeID: _sectionTypeId,
        policyItems: selectedImageBase64.value.isNotEmpty
            ? selectedImageBase64.value
            : "",
      );

      final res = await pibroRepository.addOrUpdateItemToInsure(newItem, true);
      if (res.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: res.messageResponse.message, isSuccess: false);
        return;
      }

      newPolicyItems.add(newItem);
      showSnackbarMessage(message: 'Item added.', isSuccess: true);
      _closeSheet();
    } catch (e) {
      showSnackbarMessage(message: _extractServerMessage(e), isSuccess: false);
    }
  }

  String _nextManualNumbering() {
    int max = 0;
    int toInt(String? s) {
      if (s == null) return 0;
      return int.tryParse(s) ?? 0;
    }

    void check(ItemToInsure it) {
      try {
        final v = toInt(it.manualNumbering);
        if (v > max) max = v;
      } catch (_) {}
    }

    for (final it in policyItems) check(it);
    for (final it in newPolicyItems) check(it);
    return (max + 1).toString();
  }

  void clearInputData() {
    regNoController.clear();
    chasisIdController.clear();
    engineNoController.clear();
    vehicleMakeController.clear();
    valueController.clear();
    locationController.clear();
    descriptionController.clear();
    selectedImageBase64.value = '';
  }

  void _closeSheet() {
    clearInputData();
    Get.back();
  }

  void populateInputFields(ItemToInsure data) {
    descriptionController.text = data.itemsDescription!;
    valueController.text = data.sumInsured.toString();
    locationController.text = data.itemLocation!;
  }

  void showAddOrUpdateItemSheet({ItemToInsure? data, bool isNew = false}) {
    if (data != null) {
      // populate previous image only if present on data
      if ((data.policyItems ?? '').isNotEmpty) {
        selectedImageBase64.value = data.policyItems!;
      }
      populateInputFields(data);
    } else {
      selectedImageBase64.value = '';
    }

    showAppBottomSheet(
      height: 500,
      isDismissible: false,
      child: Form(
        key: addItemFormKey,
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: GestureDetector(
                onTap: _closeSheet,
                child: Icon(
                  Icons.clear,
                  size: 30,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
            CustomInput(
              controller: valueController,
              label: AppStrings.value.tr,
              hint: '',
              validator: (value) =>
                  Validators.requiredValidator(value, AppStrings.value.tr),
            ),
            CustomInput(
              controller: locationController,
              label: AppStrings.location.tr,
              hint: '',
              validator: (value) =>
                  Validators.requiredValidator(value, AppStrings.location.tr),
            ),
            CustomInput(
              controller: descriptionController,
              label: AppStrings.description.tr,
              hint: '',
              validator: (value) => Validators.requiredValidator(
                  value, AppStrings.description.tr),
              maxLines: 3,
            ),

            // image picker + preview (renew-only)
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 20),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: pickImage,
                    child: Text(
                      AppStrings.addImage.tr,
                      style: Styles.linkTextStyle(),
                    ),
                  ),
                  const SizedBox(width: 24),
                  Obx(
                    () => selectedImageBase64.value.isNotEmpty
                        ? Expanded(
                            child: Image.memory(
                              base64Decode(selectedImageBase64.value),
                              fit: BoxFit.cover,
                              height: 100,
                            ),
                          )
                        : const SizedBox(),
                  ),
                ],
              ),
            ),

            SizedBox(height: 10),

            PolicyButton(
              text: AppStrings.save.tr,
              onPressed: () async {
                addOrUpdateItem(data: data, isNew: isNew);
              },
              height: 50,
              width: queryWidth(null) * 0.5,
              bgColor: AppColors.primaryColor,
            ),
          ],
        ),
      ),
      willPop: false,
    );
  }

  // PAYMENT FUNCTIONALITIES
  Future<void> getPaymentToken() async {
    paymentLoading.value = true;
    try {
      final response = await pibroRepository.getPaymentToken();
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        _accessToken = response.messageResponse.message;
        initializePayment(response.messageResponse.message);
      }
    } catch (e) {
      paymentLoading.value = false;
      showSnackbarMessage(
          message: AppStrings.genericErrorMessage.tr, isSuccess: false);
    }
  }

  int getChargeAmount(String amount) {
    final amountToDouble = double.parse(amount);
    final usualCharge = amountToDouble * 0.015;
    final extraCharge =
        (amountToDouble > 2500 ? (usualCharge + 100) : usualCharge);
    return ((amountToDouble + (extraCharge > 2000 ? 2000 : extraCharge)) * 100)
        .round();
  }

  Future<void> initializePayment(String token) async {
    try {
      final response = await pibroRepository.initializePayment(
          token, getChargeAmount(policyPremiumAmount));
      if (!response.initData.status) {
        showSnackbarMessage(
            message: response.initData.message!, isSuccess: false);
        paymentLoading.value = false;
      } else {
        createReceiptRequest.checkNumber = response.initData.data!.reference;
        Get.to(
          () => PaymentScreen(
              paystackUrl: response.initData.data!.authorizationUrl!),
        );
      }
    } catch (e) {
      paymentLoading.value = false;
      showSnackbarMessage(
          message: AppStrings.genericErrorMessage.tr, isSuccess: false);
    }
  }

  Future<void> sendItemsToBackend() async {
    if (policyItems.isNotEmpty) {
      await sendPolicyItems(policyItems, false);
    }
    if (newPolicyItems.isNotEmpty) {
      await sendPolicyItems(newPolicyItems, true);
    }
  }

  Future<void> sendPolicyItems(List<ItemToInsure> items, bool isNew) async {
    for (final item in items) {
      try {
        await pibroRepository.addOrUpdateItemToInsure(item, isNew);
      } catch (e) {
        // Log or handle error for individual item failure
        print('Failed to send item ${item.manualNumbering}: $e');
      }
    }
  }

  Future<void> verifyPayment(String reference) async {
    paymentLoading.value = true;
    try {
      final response =
          await pibroRepository.verifyPayment(_accessToken, reference);
      final data = response.verificationData.data;
      final status = data?.status?.toLowerCase();

      if (status != 'success') {
        showSnackbarMessage(
          message: response.verificationData.message ??
              AppStrings.genericErrorMessage.tr,
          isSuccess: false,
        );
        paymentLoading.value = false;

        // Persist for screens/logs
        lastPaymentReference = data?.reference;
        lastPaymentDate = data?.paidAt ?? DateTime.now().toIso8601String();
        lastPaymentAmount = (data?.amount ?? 0) ~/ 100;
        return;
      }

      // Persist for confirmation screen
      lastPaymentReference = data?.reference;
      lastPaymentDate = data?.paidAt ?? DateTime.now().toIso8601String();
      lastPaymentAmount = (data?.amount ?? 0) ~/ 100;

      // Build receipt from payment
      createReceiptRequest.transactionDate = lastPaymentDate;
      createReceiptRequest.amount = lastPaymentAmount; // kobo → NGN
      createReceiptRequest.systemDate = DateTime.now().toIso8601String();
      createReceiptRequest.channel = "Online";

      // Create + Post receipt (await both); postReceipt will continue the flow
      await createReceipt(createReceiptRequest);
    } catch (e, st) {
      paymentLoading.value = false;
      print('verifyPayment error: $e\n$st');
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  void checkPaymentStatus(String url) {
    if (url.contains("powersoftrd.com/EnterpriseDemo")) {
      Get.back();
      // showSnackbarMessage(message: 'Your transaction was successful!');
      verifyPayment(url.substring(url.length - 10));
    }
  }

  Future<void> createReceipt(CreateReceiptRequest requestData) async {
    try {
      final response = await pibroRepository.createReceipt(requestData);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        createReceiptRequest.receiptID = response.messageResponse.message;
        await postReceipt(createReceiptRequest); // <- ensure ordering
      }
    } catch (e) {
      paymentLoading.value = false;
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> postReceipt(CreateReceiptRequest requestData) async {
    try {
      final response = await pibroRepository.postReceipt(requestData);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        // Renewal path
        updateInsurancePolicy();
      }
    } catch (e) {
      paymentLoading.value = false;
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> renewPolicy() async {
    PolicyData dataToSend = policy.value!;
    try {
      final response = await pibroRepository.renewPolicy(dataToSend);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        updateInsurancePolicy();
      }
    } catch (e) {
      paymentLoading.value = false;
      print(e);
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> updateInsurancePolicy() async {
    _renewPolicyRequest = RenewPolicyRequest(
      policyBrokerID: policy.value!.policyBrokerID,
      policyStartDate: startDate.value!.toIso8601String(),
      policyEndDate: endDate.value!.toIso8601String(),
      renewalDate: endDate.value!.add(Duration(days: 1)).toString(),
    );
    // data.policyStartDate = startDate.value!.toIso8601String();
    // data.policyEndDate = endDate.value!.toIso8601String();
    // data.renewalDate = endDate.value!.add(Duration(days: 1)).toString();
    try {
      final response = await pibroRepository.updatePolicy(_renewPolicyRequest);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        bookPolicy();
      }
    } catch (e) {
      paymentLoading.value = false;
      print(e);
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> bookPolicy() async {
    try {
      final response = await pibroRepository.bookPolicy(_renewPolicyRequest);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        postPolicy();
      }
    } catch (e) {
      paymentLoading.value = false;
      print(e);
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> postPolicy() async {
    try {
      final response = await pibroRepository.postPolicy(_renewPolicyRequest);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        createClientNote();
      }
    } catch (e) {
      paymentLoading.value = false;
      print(e);
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> createClientNote() async {
    clientNoteRequest.policyBrokerID = policy.value!.policyBrokerID;
    clientNoteRequest.startDate = startDate.value!.toIso8601String();
    clientNoteRequest.endDate = endDate.value!.toIso8601String();
    clientNoteRequest.renewalDate =
        endDate.value!.add(Duration(days: 1)).toString();
    clientNoteRequest.sumInsured = policy.value!.sumInsured;
    clientNoteRequest.invoiceDate = createReceiptRequest.transactionDate;
    clientNoteRequest.premiumDue = double.parse(policyPremiumAmount);
    // clientNoteRequest.premiumDue = createReceiptRequest.amount!.toDouble();

    try {
      final response =
          await pibroRepository.createClientNote(clientNoteRequest);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        clientNoteRequest.invoiceNumber = response.messageResponse.message;
        bookClientNote(clientNoteRequest);
      }
    } catch (e) {
      paymentLoading.value = false;
      print(e);
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> bookClientNote(ClientNoteRequest data) async {
    try {
      final response = await pibroRepository.bookClientNote(data);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        postClientNote(data);
      }
    } catch (e) {
      paymentLoading.value = false;
      print(e);
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> postClientNote(ClientNoteRequest data) async {
    try {
      final response = await pibroRepository.postClientNote(data);
      if (response.messageResponse.status != AppConstants.responseSuccess) {
        showSnackbarMessage(
            message: response.messageResponse.message, isSuccess: false);
        paymentLoading.value = false;
      } else {
        // ✅ Navigate here, once, after debit note is posted
        if (isQuoteFlow) {
          Get.offNamed(AppRoutes.quoteConfirmation, arguments: {
            'policyId': policy.value?.policyBrokerID ?? '',
            'paymentReference': lastPaymentReference ?? '',
            'paymentDate': lastPaymentDate ?? '',
            'paymentMethod': 'Card',
            'paymentAmount': lastPaymentAmount ?? 0,
          });
        } else {
          Get.offNamed(AppRoutes.paymentConfirmation);
        }
      }
    } catch (e) {
      paymentLoading.value = false;
      print(e);
      showSnackbarMessage(
        message: _extractServerMessage(e), // <- changed here
        isSuccess: false,
      );
    }
  }

  Future<void> savePageAsPdf() async {
    try {
      // 1. Capture the widget as an image
      final Uint8List? imageBytes = await screenshotController.capture(
        delay: const Duration(milliseconds: 10),
      );

      if (imageBytes == null) {
        showSnackbarMessage(
            message: 'Failed to capture widget.', isSuccess: false);
        return;
      }

      // 2. Create a PDF document
      final pdf = pw.Document();
      final image = pw.MemoryImage(imageBytes);

      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return pw.Center(
              child: pw.Image(image),
            );
          },
        ),
      );

      // 3. Get the temporary directory
      final Directory tempDir = await getTemporaryDirectory();
      final String fileName =
          'invoice_${DateTime.now().millisecondsSinceEpoch}.pdf';
      final String filePath = '${tempDir.path}/$fileName';
      final File file = File(filePath);

      // 4. Save the PDF to the temporary file
      await file.writeAsBytes(await pdf.save());

      // 5. Share the file
      final xFile = XFile(filePath);

      await Share.shareXFiles(
        [xFile],
        text: 'Here is the exported invoice!',
        subject: 'Invoice PDF',
      );
    } catch (e) {
      print(e);
      showSnackbarMessage(
          message: 'Failed to export invoice as PDF: $e', isSuccess: false);
    }
  }

  void init() {
    final args = Get.arguments;

    if (args is PolicyData) {
      // RENEWAL FLOW: a full PolicyData is passed via navigation
      policy.value = args;
      policyItems.value = policy.value!.itemsToInsure ?? [];
    } else {
      // QUOTE FLOW: build a minimal PolicyData from the persisted enquiry
      final enquiry = GetStorage().read(StorageKeys.lastEnquiry) as Map? ?? {};

      final double sumInsured = (enquiry['sumInsured'] is num)
          ? (enquiry['sumInsured'] as num).toDouble()
          : double.tryParse(enquiry['sumInsured']?.toString() ?? '0') ?? 0.0;

      final double premiumAmount = (enquiry['premium'] is num)
          ? (enquiry['premium'] as num).toDouble()
          : double.tryParse(enquiry['premium']?.toString() ?? '0') ?? 0.0;

      policy.value = PolicyData(
        // these three are REQUIRED by your model
        companyID: (enquiry['CompanyID'] ?? 'DEMO').toString(),
        divisionID: (enquiry['DivisionID'] ?? 'DEFAULT').toString(),
        departmentID: (enquiry['DepartmentID'] ?? 'DEFAULT').toString(),

        // minimal identifiers for the screens to render
        policyBrokerID: (enquiry['caseId'] ?? '').toString(),
        businessClassID:
            (enquiry['businessClassID'] ?? enquiry['businessClassName'] ?? '')
                .toString(),
        riskTypeID:
            (enquiry['riskTypeID'] ?? enquiry['riskName'] ?? '').toString(),

        // numeric fields parsed safely
        sumInsured: sumInsured,
        premiumAmount: premiumAmount,
        // itemsToInsure is intentionally omitted here (none in quote flow yet)
      );

      policyItems.clear();
    }

    // Date fields for subsequent flows (kept as before)
    startDate.value = DateTime.now();
    endDate.value = DateTime.now().add(const Duration(days: 364));
    startDateController.text = formatDate(startDate.value.toString());
    endDateController.text = formatDate(endDate.value.toString());
    renewalDateController.text =
        formatDate(endDate.value!.add(const Duration(days: 1)).toString());
  }

  Map<String, dynamic> _toMap(dynamic raw) {
    if (raw is Map) return Map<String, dynamic>.from(raw);
    if (raw is String) {
      try {
        final m = jsonDecode(raw);
        if (m is Map) return Map<String, dynamic>.from(m);
      } catch (_) {}
    }
    return <String, dynamic>{};
  }

  String _pickCustomerId(Map<String, dynamic> m) {
    for (final k in const [
      'customerID',
      'CustomerID',
      'customerId',
      'CustomerId',
      'username',
      'Username'
    ]) {
      final v = m[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString();
    }
    return '';
  }

  /// Try multiple sources for robustness:
  /// - decryptData(StorageKeys.loginData)  (Map or JSON string)
  /// - GetStorage().read(StorageKeys.loginData)
  /// - GetStorage().read(StorageKeys.profileData)
  /// - GetStorage().read(StorageKeys.signupID)

// --- Error helpers: prefer server-sent messages over generic text ---
  String _extractServerMessage(Object e, {String? fallback}) {
    // Default fallback
    final fb = fallback ?? AppStrings.genericErrorMessage.tr;

    // 1) Try typical HTTP client shapes (e.g. Dio: e.response.data, http: custom)
    try {
      final dynamic de = e;

      // Custom error model with messageResponse?
      final dynamic mr = (de as dynamic).messageResponse;
      final dynamic mrMsg =
          mr is dynamic ? (mr.message ?? mr['message'] ?? mr['Message']) : null;
      if (mrMsg is String && mrMsg.trim().isNotEmpty) return mrMsg.trim();

      // Plain .message field on exception
      final dynamic m = (de as dynamic).message;
      if (m is String && m.trim().isNotEmpty) return m.trim();
    } catch (_) {}

    // 2) Well-known Dart exceptions
    if (e is SocketException)
      return 'Network error. Please check your connection and try again.';
    if (e is HttpException) return e.message;
    if (e is FormatException) return e.message;

    // 3) String/JSON payload
    final s = e.toString();
    if (s.isNotEmpty) {
      // Try to fish out JSON message from a stringified payload
      final fromString = _messageFromData(s);
      if (fromString != null && fromString.trim().isNotEmpty)
        return fromString.trim();
      // Trim "Exception:" noise
      final idx = s.indexOf('Exception:');
      if (idx >= 0 && idx + 10 < s.length) return s.substring(idx + 10).trim();
      return s;
    }

    return fb;
  }

  String? _messageFromData(dynamic data) {
    if (data == null) return null;

    // If server sent a string, try JSON decode then fall back to raw
    if (data is String) {
      final d = _tryJsonDecode(data);
      if (d is Map) return _messageFromMap(d) ?? data;
      return data;
    }
    if (data is Map) return _messageFromMap(data);

    return null;
  }

  String? _messageFromMap(Map map) {
    // Common keys
    final keys = const [
      'message',
      'Message',
      'error',
      'Error',
      'detail',
      'Detail',
      'errors',
      'Errors'
    ];
    for (final k in keys) {
      if (!map.containsKey(k)) continue;
      final v = map[k];
      if (v == null) continue;

      // direct string
      if (v is String && v.trim().isNotEmpty) return v.trim();

      // list of errors -> join first few
      if (v is List && v.isNotEmpty) {
        final parts = v
            .take(3)
            .map((e) => e?.toString() ?? '')
            .where((s) => s.isNotEmpty)
            .toList();
        if (parts.isNotEmpty) return parts.join('\n');
      }

      // nested map { field: ["msg"] }
      if (v is Map && v.isNotEmpty) {
        final buf = <String>[];
        v.forEach((key, val) {
          if (val is List && val.isNotEmpty) {
            buf.add('${key.toString()}: ${val.first.toString()}');
          } else if (val != null) {
            buf.add('${key.toString()}: ${val.toString()}');
          }
        });
        if (buf.isNotEmpty) return buf.join('\n');
      }
    }
    return null;
  }

  dynamic _tryJsonDecode(String s) {
    try {
      return jsonDecode(s);
    } catch (_) {
      return null;
    }
  }

  @override
  void onInit() {
    init();
    super.onInit();
  }

  @override
  void dispose() {
    clearInputData();
    super.dispose();
  }
}
